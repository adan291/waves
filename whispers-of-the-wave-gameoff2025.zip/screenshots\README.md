# Screenshots

Add screenshots here for itch.io and GitHub:

1. `splash.png` - Wave selection screen
2. `conversation.png` - Main chat interface
3. `achievements.png` - Achievement gallery
4. `dark-theme.png` - Dark theme view
5. `light-theme.png` - Light theme view

Recommended sizes:
- GitHub README: 800x600 or 1200x800
- itch.io cover: 630x500
- itch.io screenshots: 1920x1080 or 1280x720
